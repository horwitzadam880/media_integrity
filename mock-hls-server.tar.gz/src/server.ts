import express, { Request, Response } from "express";
import fs from "fs";
import path from "path";

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 8080;
const BASE_URL = `http://localhost:${PORT}`;

// ─── Fixture paths ────────────────────────────────────────────────────────────
const FIXTURES_DIR = path.join(__dirname);
const PLAYLIST_PATH = path.join(FIXTURES_DIR, "playlist.m3u8");
const AUDIO_PATH = path.join(FIXTURES_DIR, "audio.m3u8");
const VIDEO_PATH = path.join(FIXTURES_DIR, "video.m3u8");

// ─── URL rewriting ────────────────────────────────────────────────────────────
// Dropbox preview URLs all share this host prefix. We replace the full origin
// so every URL in the playlist points at our local server instead.
const DROPBOX_ORIGIN_RE =
  /https:\/\/[a-zA-Z0-9]+\.previews\.dropboxusercontent\.com/g;

function rewritePlaylist(content: string): string {
  return content.replace(DROPBOX_ORIGIN_RE, BASE_URL);
}

// ─── Synthetic .ts segment generation ────────────────────────────────────────
// A real MPEG-TS file starts with 0x47 sync bytes. We generate a deterministic
// fake that is valid enough for ffprobe / your scraper to receive and hash.
//
// Key insight: the Dropbox opaque token in the URL path is meaningless to us.
// The only semantically important params are:
//   segment_num   – position in stream
//   segment_type  – "audio" | "video"
//   size          – (video only) e.g. "1152x864"
//   bps / hw_*    – ignored; kept in URL but not used here
//
// We produce a 188-byte-aligned fake TS buffer whose content is a deterministic
// function of (segment_num, segment_type, size).  Same inputs → same bytes →
// same SHA-256 every time.  That lets you test hash-consistency logic.

const TS_PACKET_SIZE = 188;
const FAKE_SEGMENT_PACKETS = 64; // ~12 KB per segment — small but real-shaped

function makeFakeSegment(
  segmentNum: number,
  segmentType: string,
  size: string
): Buffer {
  const totalBytes = TS_PACKET_SIZE * FAKE_SEGMENT_PACKETS;
  const buf = Buffer.alloc(totalBytes, 0x00);

  for (let i = 0; i < FAKE_SEGMENT_PACKETS; i++) {
    const offset = i * TS_PACKET_SIZE;
    // Byte 0: sync byte (required by spec)
    buf[offset] = 0x47;
    // Bytes 1-2: PID — encode segment type in high nibble for easy inspection
    const pidBase = segmentType === "audio" ? 0x100 : 0x200;
    const pid = pidBase + (segmentNum % 0x1f);
    buf[offset + 1] = (pid >> 8) & 0x1f;
    buf[offset + 2] = pid & 0xff;
    // Byte 3: continuity counter
    buf[offset + 3] = i & 0x0f;
    // Bytes 4+: payload — stamp segment identity so each is unique
    const label = `seg=${segmentNum}|type=${segmentType}|size=${size}|pkt=${i}`;
    buf.write(label, offset + 4, "ascii");
  }

  return buf;
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// Dropbox HLS paths look like:
//   /p/hls_playlist/<opaque_token>/p.m3u8?...
//   /p/hls_segment/<opaque_token>/p.ts?...
//
// We match on the /p/hls_playlist and /p/hls_segment prefixes and ignore the
// opaque token entirely, routing by query params instead.

// Master playlist
app.get("/p/hls_playlist/:token/p.m3u8", (req: Request, res: Response) => {
  const { type, bps, size } = req.query as Record<string, string>;

  let content: string;

  if (!type) {
    // Master playlist — no type param
    content = rewritePlaylist(fs.readFileSync(PLAYLIST_PATH, "utf8"));
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.send(content);
    return;
  }

  if (type === "audio") {
    content = rewritePlaylist(fs.readFileSync(AUDIO_PATH, "utf8"));
  } else if (type === "video") {
    content = rewritePlaylist(fs.readFileSync(VIDEO_PATH, "utf8"));
  } else {
    res.status(400).send(`Unknown playlist type: ${type}`);
    return;
  }

  console.log(`[playlist] type=${type} bps=${bps ?? "-"} size=${size ?? "-"}`);
  res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
  res.send(content);
});

// Segment
app.get("/p/hls_segment/:token/p.ts", (req: Request, res: Response) => {
  const {
    segment_num,
    segment_type,
    size = "",
    hw_acceleration,
  } = req.query as Record<string, string>;

  if (segment_num === undefined || segment_type === undefined) {
    res
      .status(400)
      .send("Missing required query params: segment_num, segment_type");
    return;
  }

  const num = parseInt(segment_num, 10);
  if (isNaN(num)) {
    res.status(400).send(`Invalid segment_num: ${segment_num}`);
    return;
  }

  console.log(
    `[segment] num=${num} type=${segment_type} size=${size || "-"} hw=${hw_acceleration ?? "-"}`
  );

  const data = makeFakeSegment(num, segment_type, size);

  // Dropbox sets aggressive caching on segments — mirror that so your scraper
  // can test cache-control handling.
  res.setHeader("Content-Type", "video/mp2t");
  res.setHeader("Cache-Control", "public, max-age=31536000");
  res.setHeader("Content-Length", data.length.toString());
  res.send(data);
});

// Health check
app.get("/health", (_req, res) => res.json({ ok: true, port: PORT }));

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\nMock HLS server running at ${BASE_URL}`);
  console.log(`\nEndpoints:`);
  console.log(
    `  Master playlist : ${BASE_URL}/p/hls_playlist/TOKEN/p.m3u8`
  );
  console.log(
    `  Audio playlist  : ${BASE_URL}/p/hls_playlist/TOKEN/p.m3u8?type=audio&bps=128000`
  );
  console.log(
    `  Video playlist  : ${BASE_URL}/p/hls_playlist/TOKEN/p.m3u8?type=video&size=1152x864`
  );
  console.log(
    `  Segment         : ${BASE_URL}/p/hls_segment/TOKEN/p.ts?segment_num=0&segment_type=audio`
  );
  console.log();
});

export default app;
